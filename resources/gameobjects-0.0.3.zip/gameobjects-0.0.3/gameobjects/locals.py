

( WRAP_REPEAT,
  WRAP_CLAMP,
  WRAP_ERROR ) = range(3)
